Block Matching
==============

Using OpenCV's block matching optical flow algorithm within openFrameworks.

Initial test to get used to openFrameworks and OpenCV.
