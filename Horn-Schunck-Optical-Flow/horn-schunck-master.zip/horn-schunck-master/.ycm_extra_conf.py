def FlagsForFile(filename):
    return {
        'flags': ['-std', '-I/anaconda3/include', 'c++11', '-Wall', '-O0', '-g', '-fPIC'],
    }
